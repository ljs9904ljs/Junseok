from myScalar import myScalar
from myMatrix import myMatrix
from myString import myString

# main function
if __name__ == '__main__':
	a = myScalar(3.0)
	aa = myScalar(7.2)
	b = myMatrix(2,3,[0.0,0.0,1.0,0.0,2.0,0.0])
	c = myString('abc')
	

	print(b)
	d = a + b
	print(d, end='\n\n')

	e = a + c
	print(e)

	f = a + aa
	print(f)