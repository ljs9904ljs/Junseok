

#ifndef __DEFAULT_H__
#define __DEFAULT_H__

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

// ��� ����
#define MAX_NUM_MEMBER 50
#define MAX_NUM_VOTE 100
#define MAX_NUM_VOTEITEM 10
#define MAX_STRING 32
#define COMMAND_LOG_FILE_NAME "commandLog.txt"
#endif