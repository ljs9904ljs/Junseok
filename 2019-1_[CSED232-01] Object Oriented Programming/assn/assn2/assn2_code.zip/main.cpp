﻿// 헤더 선언
#include "default.h"
//파일 포인터
extern void doTask();


int main(){
	// 파일 입출력을 위한 초기화
	doTask();
	return 0;
}

