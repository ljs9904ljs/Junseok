/*
학번: 20180551
이름: 이준석
povis ID: ljs9904ljs

명예서약(Honor code)

“나는 이 프로그래밍 과제를 다른 사람의 부적절한 도움 없이 완수하였습니다.”
*/


// 헤더 선언
#include "default.h"
//파일 포인터
extern void doTask();


int main() {
	// 파일 입출력을 위한 초기화
	doTask();
	return 0;
}


