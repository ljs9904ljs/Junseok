#ifndef GAME_WINDOW_H
#define GAME_WINDOW_H

#include <QWidget>
#include "market.h"
#include "inventory.h"
#include "minigamebase.h"
#include "include/model/player.h"
#include "include/model/item.h"

// 추가한 헤더파일 5월 25일 23시 6분 __이준석
#include <QPushButton>
#include "fame_hall.h"

#include <QMessageBox>

namespace Ui {
class Game_window;
}

class Game_window : public QWidget
{
    Q_OBJECT

public:
    explicit Game_window(QWidget *parent = nullptr);
    ~Game_window();

    void setPushButtonIcon(QPushButton *btn, QString &img);
    void setPushButtonIcon2(QPushButton *btn, QString &img);
    void setPetImageFile();

    void printMsgBox(const char *text);
    bool printYNBox(const char *text);


private slots:
    void on_quit_button_clicked();

   // void on_market_clicked();

   // void on_mini_game_clicked();
    void setPetStat_show();
    void DateFatigueMoney_show();

    /* Market */
    void on_market_clicked();

    void get_item(Item item);

    /* Inventory */
    void on_inventory_clicked();

    void on_mini_game_clicked();

    void use_item(int itemNum);


    void on_pushButton_4_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_8_clicked();

    void on_save_button_clicked();

    void award();

signals:
    void goToMainWindow();

    void showCurrentStat();
    void showCurrentDateFatigueMoney();
private:
    Ui::Game_window *ui;

    market* Market;
    inventory* Inven;
    MiniGameBase * MGB;

    player* user;

};

#endif // GAME_WINDOW_H
