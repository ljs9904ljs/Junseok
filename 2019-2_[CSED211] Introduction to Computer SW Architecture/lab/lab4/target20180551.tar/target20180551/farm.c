/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_185(unsigned *p)
{
    *p = 3251079496U;
}

unsigned getval_195()
{
    return 3251079496U;
}

unsigned addval_367(unsigned x)
{
    return x + 2420646223U;
}

void setval_409(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_397()
{
    return 1069781080U;
}

unsigned getval_149()
{
    return 3281017043U;
}

unsigned addval_352(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_357()
{
    return 1610794840U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_271()
{
    return 3281180297U;
}

unsigned addval_244(unsigned x)
{
    return x + 683857545U;
}

void setval_458(unsigned *p)
{
    *p = 717408905U;
}

unsigned getval_475()
{
    return 3268839775U;
}

unsigned getval_333()
{
    return 3682915977U;
}

unsigned addval_456(unsigned x)
{
    return x + 3397951219U;
}

void setval_264(unsigned *p)
{
    *p = 3286272328U;
}

void setval_444(unsigned *p)
{
    *p = 3286272072U;
}

void setval_217(unsigned *p)
{
    *p = 3229925785U;
}

unsigned addval_431(unsigned x)
{
    return x + 3348158089U;
}

void setval_183(unsigned *p)
{
    *p = 3676359305U;
}

unsigned getval_310()
{
    return 3281049257U;
}

void setval_485(unsigned *p)
{
    *p = 3225995913U;
}

void setval_338(unsigned *p)
{
    *p = 3223374475U;
}

unsigned getval_169()
{
    return 3286272328U;
}

void setval_411(unsigned *p)
{
    *p = 2445379946U;
}

unsigned addval_100(unsigned x)
{
    return x + 3222847881U;
}

unsigned getval_267()
{
    return 3286272330U;
}

unsigned addval_131(unsigned x)
{
    return x + 3247489417U;
}

unsigned getval_315()
{
    return 2430642504U;
}

unsigned getval_186()
{
    return 3286272072U;
}

void setval_390(unsigned *p)
{
    *p = 3682912905U;
}

unsigned getval_189()
{
    return 3352725938U;
}

void setval_305(unsigned *p)
{
    *p = 3281046152U;
}

unsigned getval_236()
{
    return 2430642504U;
}

unsigned getval_498()
{
    return 3372794249U;
}

unsigned addval_126(unsigned x)
{
    return x + 3397498142U;
}

unsigned addval_111(unsigned x)
{
    return x + 3284240538U;
}

unsigned getval_239()
{
    return 3375945353U;
}

void setval_426(unsigned *p)
{
    *p = 3531915657U;
}

unsigned addval_324(unsigned x)
{
    return x + 3286272360U;
}

unsigned getval_158()
{
    return 2425405897U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
